export const saveUser=(payload)=>{
    return {type: 'saveUser', payload:payload}
}